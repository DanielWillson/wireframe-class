function mouseOver(obj) {
    obj.innerHTML = "You're hovering!";
}
